import React from "react";
import "./../../App.css";

class Abouts extends React.Component {
  render() {
    return (
      <div>
        <h1>About</h1>
      </div>
    );
  }
}

export default Abouts;
