# CSE611_Project - PropTech
Group Member: Xinyu Chen, Zhenduo Lin, Min Dong, Xianxin Lin, Raymond Zheng